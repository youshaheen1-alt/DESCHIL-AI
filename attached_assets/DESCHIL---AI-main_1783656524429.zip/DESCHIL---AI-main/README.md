# DESCHIL SERVER

Unified AI automation backend. One command bus is shared by the web dashboard, Telegram, WhatsApp (Green API or Meta Cloud), and Discord (HTTP interactions). Bring your own AI keys — providers are auto-detected from environment variables and used with automatic fallback.

Built on **TanStack Start** (React 19 + Vite 8) with a **Nitro `node-server`** output for **Railway** deployment. Postgres for auth, sessions, role-based access, and command auditing.

---

## Quick start (local)

```bash
cp .env.example .env
# fill in DATABASE_URL, SESSION_SECRET, and any provider/bot keys you want

bun install     # or: npm install
bun run dev     # local dev on http://localhost:3000
```

Build & run the production bundle:

```bash
bun run build
node dist/server/index.mjs
```

---

## Deploy on Railway

1. **Create the service** from this repo. Railway detects the `Dockerfile` and `railway.json` automatically.
2. **Add a Postgres plugin** and let Railway wire `DATABASE_URL` for you (or paste your own).
3. **Set environment variables** from `.env.example` — the ones you don't need can stay blank.
4. Railway builds via `docker build` and starts with `node dist/server/index.mjs`.

Every table needed by the app (`users`, `user_roles`, `sessions`, `linked_accounts`, `link_codes`, `command_audit`, `ai_config`) is created on first request by `bootstrapDatabase()` — no separate migration step.

### Docker

```bash
docker build -t deschil-server .
docker run --rm -p 3000:3000 --env-file .env deschil-server
```

---

## Environment variables

See [`.env.example`](./.env.example) for the full list. Highlights:

| Group      | Vars |
|------------|------|
| Runtime    | `PORT`, `HOST`, `NODE_ENV`, `LOG_LEVEL` |
| Database   | `DATABASE_URL` (Railway Postgres) |
| Sessions   | `SESSION_SECRET` |
| AI         | `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `OPENROUTER_API_KEY`, `GROQ_API_KEY`, `DEEPSEEK_API_KEY`, `MISTRAL_API_KEY`, `XAI_API_KEY`, `LOVABLE_API_KEY`, `GOOGLE_API_KEY`, `EXA_API_KEY`, `TAVILY_API_KEY`, `FIRECRAWL_API_KEY`, `ELEVENLABS_API_KEY` |
| Routing    | `DEFAULT_AI_PROVIDER`, `DEFAULT_AI_MODEL` |
| Telegram   | `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET` |
| WhatsApp   | `GREEN_API_TOKEN`, `GREEN_API_INSTANCE_ID` — or Meta: `WHATSAPP_PHONE_ID`, `WHATSAPP_TOKEN`, `WHATSAPP_VERIFY_TOKEN` |
| Discord    | `DISCORD_APPLICATION_ID`, `DISCORD_PUBLIC_KEY`, `DISCORD_BOT_TOKEN` |

Multiple API keys for the same provider are supported by comma-separating them:

```
OPENAI_API_KEY=sk-primary,sk-backup1,sk-backup2
```

Keys are round-robined per request to spread rate limits.

---

## Architecture

```text
+------------------+     +------------------+
| Web (dashboard)  |     | Telegram / WA /  |
| /api/command     |     | Discord webhooks |
+---------+--------+     +---------+--------+
          \                        /
           \                      /
            v                    v
        +------------------------------+
        |        Command Bus           |
        |  (registry + middleware +    |
        |   permissions + audit)       |
        +------------------------------+
                     |
                     v
        +------------------------------+
        |          AI Router           |
        |  OpenAI · Anthropic · Gemini |
        |  OpenRouter · Groq · xAI ... |
        +------------------------------+
                     |
                     v
              Postgres (Railway)
```

### Command bus

- `src/lib/commands/bus.ts` — registry, middleware chain, permission gate, audit hook.
- `src/lib/commands/core.ts` — built-in commands: `help`, `ping`, `version`, `status`, `health`, `providers`, `config`, `ai-chat`.
- Register your own commands with `registerCommand({...})`.

Aliases are auto-registered (`ai-chat` also responds to `ai`, `chat`, `ask`). Permissions: `public | user | admin`. Every dispatch writes to `command_audit`.

### AI router

- `src/lib/ai/providers.ts` — catalog of every supported provider and its base URL.
- `src/lib/ai/router.ts` — `routeChat({ messages })` picks the preferred provider then falls back through the remaining enabled ones. OpenAI-compatible providers use `/chat/completions`; Anthropic uses `/messages`.

---

## Endpoints

| Path | Method | Purpose |
|------|--------|---------|
| `/api/health` | GET | Liveness + DB ping. 200 healthy, 503 degraded. |
| `/api/status` | GET | Version, uptime, provider status, registered commands. |
| `/api/command` | POST | `{ command: "help" }` — runs against the bus as the current session. |
| `/api/public/telegram/webhook` | POST | Telegram Bot API updates. |
| `/api/public/whatsapp/webhook` | GET/POST | Green API or Meta Cloud webhook (GET handles Meta verification). |
| `/api/public/discord/interactions` | POST | Discord signed HTTP interactions. |

`/api/public/*` bypasses the session-cookie auth on published deployments and secures itself via provider signatures/secrets.

---

## Webhook setup

### Telegram

```bash
curl -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -H 'content-type: application/json' \
  -d '{
    "url": "https://<your-railway-domain>/api/public/telegram/webhook",
    "secret_token": "'"$TELEGRAM_WEBHOOK_SECRET"'",
    "allowed_updates": ["message", "edited_message", "callback_query"]
  }'
```

### WhatsApp (Green API)

In your Green API instance settings, point the webhook to
`https://<your-railway-domain>/api/public/whatsapp/webhook`. Enable **incomingMessageReceived**.

### WhatsApp (Meta Cloud)

In Meta's App Dashboard → Webhooks, use the same URL. The verify token must match `WHATSAPP_VERIFY_TOKEN` from your env.

### Discord

In the Developer Portal, set **Interactions Endpoint URL** to
`https://<your-railway-domain>/api/public/discord/interactions`. `DISCORD_PUBLIC_KEY` verifies Ed25519 signatures.

---

## Web dashboard

- `/` — public landing page.
- `/auth` — email/password sign-in and sign-up. The first account created becomes `admin`.
- `/dashboard` — user home (authenticated).
- `/console` — command console with live provider/platform status.

---

## Commands (built-in)

```
help                  Show all commands
ping                  → pong
version               DESCHIL SERVER version
status                Runtime info
health                Server + database check
providers             Which AI providers are enabled
config                (admin) Default provider/model + log level
ai-chat <prompt>      Ask the AI router
```

Add a command:

```ts
import { registerCommand } from "@/lib/commands";
registerCommand({
  name: "echo",
  description: "Echo your input.",
  handler: (ctx) => ({ text: ctx.args.join(" ") || "…" }),
});
```

---

## Troubleshooting

- **`DATABASE_URL is not set`** — the server starts but auth/audit fail. Add a Postgres plugin on Railway.
- **`All AI providers failed`** — no keys detected, or every provider returned an error. Check `/api/status` for the enabled list.
- **Telegram webhook silently 401** — `TELEGRAM_WEBHOOK_SECRET` mismatch. Compare `getWebhookInfo` output with your env.
- **Discord `invalid request signature`** — `DISCORD_PUBLIC_KEY` is missing or wrong.
- **Local Postgres over TLS** — the client only enables SSL when the URL contains `railway` or `PGSSL=require`.

---

## License

MIT.
