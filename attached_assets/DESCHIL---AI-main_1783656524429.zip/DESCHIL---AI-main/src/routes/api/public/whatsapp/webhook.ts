import { createFileRoute } from "@tanstack/react-router";
import { dispatch, ensureCommandsReady } from "@/lib/commands";
import { waSendMessage, whatsappMode } from "@/lib/integrations/whatsapp";

interface GreenIncoming {
  typeWebhook?: string;
  senderData?: { chatId: string; sender: string };
  messageData?: { textMessageData?: { textMessage?: string }; extendedTextMessageData?: { text?: string } };
}

interface MetaIncoming {
  entry?: Array<{
    changes?: Array<{
      value?: {
        messages?: Array<{ from: string; text?: { body?: string } }>;
      };
    }>;
  }>;
}

export const Route = createFileRoute("/api/public/whatsapp/webhook")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        // Meta verification handshake
        const url = new URL(request.url);
        const mode = url.searchParams.get("hub.mode");
        const token = url.searchParams.get("hub.verify_token");
        const challenge = url.searchParams.get("hub.challenge");
        if (mode === "subscribe" && token && token === process.env.WHATSAPP_VERIFY_TOKEN) {
          return new Response(challenge ?? "", { status: 200 });
        }
        return Response.json({ ok: true, mode: whatsappMode() });
      },
      POST: async ({ request }) => {
        ensureCommandsReady();
        const raw = (await request.json()) as GreenIncoming & MetaIncoming;

        // Green API shape
        if (raw.typeWebhook === "incomingMessageReceived" && raw.senderData) {
          const chatId = raw.senderData.chatId;
          const text =
            raw.messageData?.textMessageData?.textMessage ??
            raw.messageData?.extendedTextMessageData?.text ??
            "";
          if (!text) return Response.json({ ok: true, ignored: true });
          const result = await dispatch({
            platform: "whatsapp",
            roles: [],
            externalId: raw.senderData.sender,
            raw: text,
            args: [],
            reply: async (t) => { await waSendMessage(chatId, t); },
          });
          if (result.text) await waSendMessage(chatId, result.text);
          return Response.json({ ok: true });
        }

        // Meta Cloud shape
        const metaMsg = raw.entry?.[0]?.changes?.[0]?.value?.messages?.[0];
        if (metaMsg?.text?.body) {
          const result = await dispatch({
            platform: "whatsapp",
            roles: [],
            externalId: metaMsg.from,
            raw: metaMsg.text.body,
            args: [],
            reply: async (t) => { await waSendMessage(metaMsg.from, t); },
          });
          if (result.text) await waSendMessage(metaMsg.from, result.text);
          return Response.json({ ok: true });
        }
        return Response.json({ ok: true, ignored: true });
      },
    },
  },
});
