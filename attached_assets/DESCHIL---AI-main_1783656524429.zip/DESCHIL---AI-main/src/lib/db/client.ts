import { Pool } from "pg";

let _pool: Pool | null = null;

export function getPool(): Pool {
  if (_pool) return _pool;
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error("DATABASE_URL is not set");
  }
  _pool = new Pool({
    connectionString,
    ssl: connectionString.includes("railway") || process.env.PGSSL === "require"
      ? { rejectUnauthorized: false }
      : undefined,
    max: 10,
  });
  return _pool;
}

export async function query<T = unknown>(text: string, params?: unknown[]): Promise<{ rows: T[] }> {
  const pool = getPool();
  const result = await pool.query(text, params as never[]);
  return { rows: result.rows as T[] };
}
