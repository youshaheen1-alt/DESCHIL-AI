/**
 * Telegram Bot API helper. Uses direct Bot API (not the Lovable connector
 * gateway) because this app runs standalone on Railway.
 */
import { logger } from "../logger";

const log = logger.child({ mod: "telegram" });

function apiBase(): string {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN is not set");
  return `https://api.telegram.org/bot${token}`;
}

export async function tgSendMessage(chatId: number | string, text: string, extra?: Record<string, unknown>) {
  const res = await fetch(`${apiBase()}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", ...extra }),
  });
  if (!res.ok) log.warn("send.fail", { status: res.status, body: await res.text() });
  return res.ok;
}

export async function tgAnswerCallback(callbackId: string, text?: string) {
  await fetch(`${apiBase()}/answerCallbackQuery`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ callback_query_id: callbackId, text }),
  });
}

export function verifyTelegramSecret(headerValue: string | null): boolean {
  const expected = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (!expected) return true; // secret not configured — skip check
  return headerValue === expected;
}
